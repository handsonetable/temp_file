
/*Validation*/

	/*number key validation*/
			function isNumberKey(evt)
             {
	                var charCode = (evt.which) ? evt.which : event.keyCode
	                if (charCode > 31 && (charCode < 48	 || charCode > 57))
	                  	 return false;
	                return true;
             }
			
    /*business name validation*/
         	/*function business_name(bname)
         		{
				  var bnamereg =/^([a-zA-Z]{0,16})+$/;
				  var business_input_name = $(bname).val(); 
			      var valid = bnamereg.test(business_input_name);
		  			  if (!valid) {
						    toastr.warning('Alphabets Only');
						    bname.focus();
					  }else{
					  		business_input_name_length=business_input_name.length;
					  		if((business_input_name_length)==''){
					  			toastr.warning('Business name is required!');
					  			bname.focus();
					  		}else if((business_input_name_length)<=3){
		  						 toastr.warning('Minimum 4 characters are allowed');
		  						 bname.focus();
		  					}else{
		  						return true;
		  					}
					  }
			  	}*/
			  
	/*business type validation*/
			/*function business_type(btype)
			 {
				 	var btypereg=$(btype).val();
				 	if(btypereg.length==''){
				 		toastr.warning('Business type is required!');
				 		btype.focus();
				 	} else {
				 		return true;
				 	}
			 }*/
			 
	/*nature of business*/
			/*function nature_of_business(nobname)
			 {
				  var nobnamereg =/^([a-zA-Z]{0,16})+$/;
				  var nob_reg_input = $(nobname).val();
			      var valid = nobnamereg.test(nob_reg_input);
		  			  if (!valid) {
						    toastr.warning('Alphabets Only');
						    nobname.focus();
					  } else {
						  		nob_reg_input_length=nob_reg_input.length;
						  		if((nob_reg_input_length)==''){
						  			toastr.warning('Nature of business is required!');
						  			nobname.focus();
						  		}else if((nob_reg_input_length)<=3){
			  						toastr.warning('Minimum 4 characters are allowed');
			  						 nobname.focus();
			  					}else{
			  						return true;
			  					}
					  }
			  }*/
		
	/*pan validation*/

			function pan_number(event)
			 {  
				 var regExp = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/; 
				 var txtpan = $(event).val(); 
				 if (txtpan.length == 10 ) { 
				  if( txtpan.match(regExp) ){ 
				   toastr.success('PAN match found');
				  }
				  else {
				    toastr.warning('Not a valid PAN number');
				    event.focus();
				  } 
				 } 
				 else { 
				       toastr.warning('Please enter 10 digits for a valid PAN number');
				       event.focus();
				 } 

			 }

	/*Email id validation*/
			function ESI_filing_email_id(email)
			 {
				var ESI_filing_input = $(email).val(); 
				var regExp= /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
				  if (regExp.test(ESI_filing_input) == false) {
  						toastr.warning('Enter valid Email id!');
  						email.focus();
					}
				}

	/*mobile number validation*/
			function ESI_filing_mobile(mobile)
			 {
				var ESI_filing_input = $(mobile).val(); 
				var regExp = /[7-9]{1}[0-9]{9}/;
				  if (regExp.test(ESI_filing_input) == false) {
				  toastr.warning('Invalid Phone number');
				  mobile.focus();
				  } else {
				  	return true;
				  }
			 }

	/*UAN number validation*/
			function ESI_filing_UAN_no(uan)
			 {
				toastr.warning('invalid UAN');
			 }

	/*datepicker*/
			$(document).ready(function()
			 {
				$('.date-picker').datepicker({
					endDate: "today" ,
	              startView: 2
	           }); 
			 });
				 

/*PF Registration*/

	/* PF_reg_tab2*/
			/*addrow_hsn*/
			  		$(document).on("click",".add1_director_btn", function() {
						    myDataa.push({});
						    hot_balance_sheett.render();
						    return false;
					});

	/* PF_reg_tab3*/
			$(".UNA_checkbox").on('click',function()
			  {
				 if($('.UNA_checkbox').is(':checked')){
					 	$('.ESI_reg_UNA_input').hide();
					 	$('.PF_reg_director_table').fadeIn(800);
				 }else{
				 	$('.ESI_reg_UNA_input').fadeIn(800);
				 	$('.PF_reg_director_table').fadeOut(800);
				 }
			 });


	
/*ESI_return_filing*/
	
		/*tab1*/
			/*addrow*/
			$('.add_salary_paid_btn').on("click", function() {
			    ESI_rf_salary_data.push({});
			    salary_paid_hsn_init.render();
			     return false;
			});

			/*submit*/
			$(".salary_paid_hsn_submit").on('click',function(e){
				e.preventDefault();
				var salary_paid_hsn_getcontent = salary_paid_hsn_init.getSourceData();
				var salary_paid_hsn_getdata = JSON.stringify(salary_paid_hsn_getcontent);
				console.log(salary_paid_hsn_getdata);
			});

		/*tab2*/
			/*addrow*/
			$('.add_new_employee_btn').on("click", function() {
			    ESI_return_filing_new_emp_data.push({});
			    new_emp_hsn_init.render();
			    return false;
			});

			/*submit*/
			$(".new_employee_hsn_submit").on('click',function(e){
				e.preventDefault();
				var new_emp_hsn_getcontent = new_emp_hsn_init.getSourceData();
				var new_emp_hsn_getdata = JSON.stringify(new_emp_hsn_getcontent);
				console.log(new_emp_hsn_getdata);
			});
			
		/*tab3*/
			/*addrow*/
			$('.add_left_employee_btn').on("click", function() {
			    ESI_return_filing_left_emp_data.push({});
			    left_emp_hsn_init.render();
			    return false;
			});

			/*submit*/
			$(".left_hsn_submit").on('click',function(e){
				e.preventDefault();
				var left_emp_hsn_getcontent = left_emp_hsn_init.getSourceData();
				var left_emp_hsn_getdata = JSON.stringify(left_emp_hsn_getcontent);
				console.log(left_emp_hsn_getdata);
			});

/*remove hsn pro version initially*/
			
			$("#hot-display-license-info").remove();





			

/*form submit*/

		$('.PF_Reg__tab1_submit').on('click',function(e){
			e.preventDefault();
			var data = JSON.stringify( $('.PF_Reg_tab1_form').serializeArray() ); 
		  	console.log( data );
		  	return false; 
		});