/*dynamic modal*/
$( document ).ready(function() {
$('.milestone .m-list-timeline__text').on('click',function(){
	$('.modal-body .form-modal').hide();
	var type=$(this).html();
	$('.modal-title').html(type);
	if(type=="ESI Registration"){
		$('.ESI_reg_form').show();
	}else if(type=="PF Registration"){
		$('.PF_reg_form').show();
	}
});




/*modal submit*/
/*$('.form_submit').on('click',function(){
	var serialize=$('#m_modal_1 form').serializeArray();
	console.log(serialize);
});*/




	function isNumberKey(evt)
             {
                var charCode = (evt.which) ? evt.which : event.keyCode
                if (charCode > 31 && (charCode < 48	 || charCode > 57))
                   return false;
         
                return true;
             }
			

         	function business_name(bname){
			  var bnamereg =/^([a-zA-Z]{0,16})+$/;
			  var business_input_name = $(bname).val(); 
		      var valid = bnamereg.test(business_input_name);
	  			  if (!valid) {
					    toastr.warning('Alphabets Only');
					    bname.focus();
				  }else{
				  		business_input_name_length=business_input_name.length;
				  		if((business_input_name_length)==''){
				  			toastr.warning('Business name is required!');
				  			bname.focus();
				  		}else if((business_input_name_length)<=3){
	  						toastr.warning('Minimum 4 characters are allowed');
	  						 bname.focus();
	  					}else{
	  						return true;
	  					}
				  }
			  }
			  
			 function business_type(btype){
			 	var btypereg=$(btype).val();
			 	if(btypereg.length==''){
			 		toastr.warning('Business type is required!');
			 		btype.focus();
			 	}else{
			 		return true;
			 	}
			 }
			 
		/*nature of business*/
			 function nature_of_business(nobname){
			  var nobnamereg =/^([a-zA-Z]{0,16})+$/;
			  var nob_reg_input = $(nobname).val(); 
		      var valid = nobnamereg.test(nob_reg_input);
	  			  if (!valid) {
					    toastr.warning('Alphabets Only');
					    nobname.focus();
				  }else{
				  		nob_reg_input_length=nob_reg_input.length;
				  		if((nob_reg_input_length)==''){
				  			toastr.warning('Nature of business is required!');
				  			nobname.focus();
				  		}else if((nob_reg_input_length)<=3){
	  						toastr.warning('Minimum 4 characters are allowed');
	  						 nobname.focus();
	  					}else{
	  						return true;
	  					}
				  }
			  }
		/*pan validation*/

			  function pan_number(event) {  
				 var regExp = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/; 
				 var txtpan = $(event).val(); 
				 if (txtpan.length == 10 ) { 
				  if( txtpan.match(regExp) ){ 
				   toastr.success('PAN match found');
				  }
				  else {
				    toastr.warning('Not a valid PAN number');
				  } 
				 } 
				 else { 
				       toastr.warning('Please enter 10 digits for a valid PAN number');
				 } 

				}



/*datepicker*/
				$(document).ready(function(){
					$('.date-picker').datepicker({
		              startView: 2
		           }); 
				});
				 

/*company certificate*/
		$("input[name='company_certificate']").on('click',function(){
			
               $('.show_browse_certificate').fadeIn(800);
           
         });

/*office rent/own*/
			$("input[name='rent_own']").on('click',function(){
				if($('input:radio[name=company_certificate]').is(':checked')){
					 // do something
					 if($(this).val()=='Rent'){
										$('.rent_own').html('Upload Aggrement');
									}else{
										$('.rent_own').html('Upload Eb bill');
									}
								
					               $('.show_office_certificate').fadeIn(800);
					
					}else{
							$("input[name='rent_own']").prop('checked', false);
						 toastr.warning('Company certificate is mandatory!');
					}
					
				
	           
	         });
  
 /* PF_reg_tab3*/
			 $(".UNA_checkbox").on('click',function(){
			 if($('.UNA_checkbox').is(':checked')){
			 	$('.ESI_reg_UNA_input').hide();
			 	$('.PF_reg_director_table').fadeIn(800);
			 }else{
			 	$('.ESI_reg_UNA_input').fadeIn(800);
			 	$('.PF_reg_director_table').fadeOut(800);
			 }
			});

/*initiate hide*/
			$('.show_browse_certificate').hide();
		 	$('.show_office_certificate').hide();



});





/*handsontable for PF_reg_tab2*/
/*var myData1 = [  {a: '', b: '', c: ''}   ];
var hotElement_balance_sheet1 = document.querySelector('#exampleGrid1');
var hotSettings_balance_sheet1 = {
  data: myData1,
	colHeaders: ["Name", "Designation", "Address", "Aadhar number", "Mobile no","Mail id"],
   columns: [
        { data: "a", type: "text" },
        { data: "b", type: "text" },
        { data: "c", type: "text" },
        { data: "d", type: "text" },
        { data: "e", type: "text" },
        { data: "f", type: "text" }
    ],

	stretchH: 'all',
	width: 806,
	autoWrapRow: true,
	manualRowResize: true,
	manualColumnResize: true,
	rowHeaders: true,
	manualRowMove: false,
	manualColumnMove: false,
	contextMenu: true,
	filters: false,
	dropdownMenu: false,
	columnSorting: false,
	sortIndicator: true
};
var hot_balance_sheet1 = new Handsontable(hotElement_balance_sheet1, hotSettings_balance_sheet1);
/* End Revenue From Operations */

	/*$("#data_save1").click(function(){
	var htContents1 = hot_balance_sheet1.getSourceData();
	var hot_balance_sheet_data1 = JSON.stringify(htContents1);
	console.log(hot_balance_sheet_data1);
});*/




/*handsontable PF_reg_tab3*/
var myData = [  {a: '', b: '', c: ''}   ];

var hotElement_balance_sheet = document.querySelector('#exampleGrid');
var hotSettings_balance_sheet = {
  data: myData,
	colHeaders: ["Name", "Father Name", "DOB", "DOJ", "Gross.Salary","Address1","Address2","Pin","City","State","Bank account.no"],
   columns: [
        { data: "a", type: "text" },
        { data: "b", type: "text" },
        { data: "c", type: "text" },
        { data: "d", type: "text" },
        { data: "e", type: "text" },
        { data: "f", type: "text" },
        { data: "g", type: "text" },
        { data: "h", type: "text" },
        { data: "i", type: "text" },
        { data: "j", type: "text" },
        { data: "k", type: "text" }
    ],

	stretchH: 'all',
	width: "90%",
	autoWrapRow: true,
	manualRowResize: true,
	manualColumnResize: true,
	rowHeaders: true,
	manualRowMove: false,
	manualColumnMove: false,
	contextMenu: true,
	filters: false,
	dropdownMenu: false,
	columnSorting: false,
	sortIndicator: true
};
var hot_balance_sheet = new Handsontable(hotElement_balance_sheet, hotSettings_balance_sheet);
/* End Revenue From Operations */

	$("#data_save").click(function(){/*
	$("#data_save").css("pointer-events", "none");*/
	/*$("#save_button_icon").removeClass("fa-save m-animate-shake").addClass("fa-life-ring fa-spin");*/
	var htContents = hot_balance_sheet.getSourceData();
	var hot_balance_sheet_data = JSON.stringify(htContents);
	console.log(hot_balance_sheet_data);
	/*var cleanedGridData = [];
	var obj = {};
	$.each( htContents, function( rowKey, object) {
		if (!hot_balance_sheet.isEmptyRow(rowKey)){
		cleanedGridData.push(visualObjectRow(hot_balance_sheet, rowKey));
		}
	});
	var hot_balance_sheet_data = JSON.stringify(cleanedGridData);
	*/
});
