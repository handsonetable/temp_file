

/*handsontable ESI_return_filing_tab1*/
		 var ESI_rf_salary_data = [  ];

			var hotElement_balance_sheett = document.querySelector('#salary_paid_hsn');
			var hotSettings_balance_sheett = {
			  data: ESI_rf_salary_data,
				colHeaders:   ["Name", "Gross Salary", "Net Slary", "UAN no"],

			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "numeric" },
			        { data: "c", type: "numeric" },
			        { data: "d", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [20,20,20,20,20],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var salary_paid_hsn_init = new Handsontable(hotElement_balance_sheett, hotSettings_balance_sheett);
			/*var myDataa = [  {a: '', b: '', c: ''}   ];
			var hotElement_balance_sheett = document.querySelector('#exampleGridd');
			var hotSettings_balance_sheett = {
			  data: myDataa,
				colHeaders:  ["Name", "Designation", "Address", "Aadhar number", "Mobile no","Mail id"],
			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "text" },
			        { data: "d", type: "text" },
			        { data: "e", type: "text" },
			        { data: "f", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [10,10,10,10,10,10,10,10,10,10,10],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var hot_balance_sheett = new Handsontable(hotElement_balance_sheett, hotSettings_balance_sheett);
			*/







/*handsontable ESI_return_filing_tab2*/
			var ESI_return_filing_new_emp_data = [  {a: '', b: '', c: ''}   ];

			var hotElement_balance_sheet = document.querySelector('#new_employee_hsn');
			var hotSettings_balance_sheet = {
			  data: ESI_return_filing_new_emp_data,
				colHeaders:   ["Name", "Gross Salary", "Net Slary","Aadhar card","PAN no", "UAN no"],
			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "numeric" },
			        { data: "c", type: "numeric" },
			        { data: "d", type: "numeric" },
			        { data: "e", type: "text" },
			        { data: "f", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [20,20,10,10,20,20],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var new_emp_hsn_init = new Handsontable(hotElement_balance_sheet, hotSettings_balance_sheet);
			/* End Revenue From Operations */



/*handsontable ESI_return_filing_tab3*/
			var ESI_return_filing_left_emp_data = [  {a: '', b: '', c: ''}   ];

			var ESI_return_filing_left_emp_Element = document.querySelector('#left_employee_hsn');
			var ESI_return_filing_left_emp_settings = {
			  data: ESI_return_filing_left_emp_data,
				colHeaders:   ["Name", "Gross Salary", "Net Slary", "select"],
			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "numeric" },
			        { data: "c", type: "numeric" },
			        { data: "d", type: "dropdown", source: ['UAN no','Insurance no'] }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [20,20,20,20],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var left_emp_hsn_init = new Handsontable(ESI_return_filing_left_emp_Element, ESI_return_filing_left_emp_settings);
