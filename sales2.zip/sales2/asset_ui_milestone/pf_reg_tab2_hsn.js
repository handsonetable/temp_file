

/*handsontable PF_reg_tab2*/
		 var myDataa = [  {a: '', b: '', c: ''}   ];

			var hotElement_balance_sheett = document.querySelector('#exampleGridd');
			var hotSettings_balance_sheett = {
			  data: myDataa,
				colHeaders:  ["Name", "Designation", "Address", "Aadhar number", "Mobile no","Mail id"],

			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "text" },
			        { data: "d", type: "text" },
			        { data: "e", type: "text" },
			        { data: "f", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [20,20,20,10,15,15],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var hot_balance_sheett = new Handsontable(hotElement_balance_sheett, hotSettings_balance_sheett);
			/*var myDataa = [  {a: '', b: '', c: ''}   ];
			var hotElement_balance_sheett = document.querySelector('#exampleGridd');
			var hotSettings_balance_sheett = {
			  data: myDataa,
				colHeaders:  ["Name", "Designation", "Address", "Aadhar number", "Mobile no","Mail id"],
			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "text" },
			        { data: "d", type: "text" },
			        { data: "e", type: "text" },
			        { data: "f", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [10,10,10,10,10,10,10,10,10,10,10],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var hot_balance_sheett = new Handsontable(hotElement_balance_sheett, hotSettings_balance_sheett);
			*/





/*handsontable PF_reg_tab3*/
			var myData = [  {a: '', b: '', c: ''}   ];

			var hotElement_balance_sheet = document.querySelector('#exampleGrid');
			var hotSettings_balance_sheet = {
			  data: myData,
				colHeaders: ["Name", "Father Name", "DOB", "DOJ", "Gross.Salary","Address1","Address2","Pin","City","State","Bank account.no"],
			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "date" },
			        { data: "d", type: "date" },
			        { data: "e", type: "numeric" },
			        { data: "f", type: "text" },
			        { data: "g", type: "text" },
			        { data: "h", type: "numeric" },
			        { data: "i", type: "text" },
			        { data: "j", type: "text" },
			        { data: "k", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [10,10,10,10,10,10,10,10,10,10,10],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};
			var hot_balance_sheet = new Handsontable(hotElement_balance_sheet, hotSettings_balance_sheet);
			/* End Revenue From Operations */

				$("#data_save").click(function(e){
				e.preventDefault();
				/*
				$("#data_save").css("pointer-events", "none");*/
				/*$("#save_button_icon").removeClass("fa-save m-animate-shake").addClass("fa-life-ring fa-spin");*/
				var htContents = hot_balance_sheet.getSourceData();
				var hot_balance_sheet_data = JSON.stringify(htContents);
				console.log(hot_balance_sheet_data);
				/*var cleanedGridData = [];
				var obj = {};
				$.each( htContents, function( rowKey, object) {
					if (!hot_balance_sheet.isEmptyRow(rowKey)){
					cleanedGridData.push(visualObjectRow(hot_balance_sheet, rowKey));
					}
				});
				var hot_balance_sheet_data = JSON.stringify(cleanedGridData);
				*/
			});


			$(document).on("click",".add_director_btn", function() {
			    myData.push({a: '', b: '', c: '',d: '', e: '', f: ''});
			    hot_balance_sheet.render();
			    return false;
			});

