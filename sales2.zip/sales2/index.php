


<script src="assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
		<script src="assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
		<link href="assets/handsontable/dist/handsontable.full.min.css" rel="stylesheet" media="screen">
		<script src="assets/handsontable/dist/handsontable.full.min.js"></script>


<!--modal begin-->
	
      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel"> <?php	if($_REQUEST['eid']=='2') { echo "PF Registration"; } ?></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">×</span>
	        </button>
      </div>
      <div class="modal-body">
	       	<!--display form dynamically here-->
	      <?php	if($_REQUEST['eid']=='2') { ?>
	       	<!--ESI form reg-->
	       		<div class="form-modal PF_reg_form">
		        	<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item ">
							<a class="nav-link active" data-toggle="tab" href="#m_tabs_1_1">
								PF Registration
							</a>
						</li>
						<li class="nav-item dropdown">
							<a class="nav-link click_trigger" data-toggle="tab" href="#m_tabs_1_2" >
								Authorized Person / Directors
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#m_tabs_1_3">
								Employers details
							</a>
						</li>
					</ul>
		            <div class="tab-content">
						<div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
							<form class="PF_Reg_tab1_form" id="PF_Reg_tab1_form" method="POST">
								<div class="form-group m-form__group row">
										<div class="col-lg-6">
											<label>Business Name:</label>
											<input class="form-control m-input" name="business_name" type="text" id="PF_reg_business_name"  required>
										</div>
										<div class="col-lg-6">
											<label class="">Business Type:</label>
											<select class="form-control m-input" name="business_type" id="PF_reg_business_type"   required>
												<option value="" selected>Select business type</option>
												<option value="BPLC">B PLC</option>
												<option vlaue="LLP">LLP</option>
												<option value="Proprietor">Proprietor</option>
											</select>
										</div>
									</div>
								<div class="form-group m-form__group row">
										<div class="col-lg-6">
											<label>Nature of Business:</label>
											<input class="form-control m-input" type="text" name="nature_of_business"  id="PF_reg_nature_of_business" required>
										</div>
										<div class="col-lg-6">
											<label class="">Company PAN no:</label>
											<input class="form-control m-input" onblur="pan_number(this);" name="company_pan_no" type="text" id="PF_reg_company_pan_no" required>
										</div>
									</div>
								<div class="form-group m-form__group row">
										<div class="col-lg-6">
											<label>Company certificate:</label>
											<div class="m-radio-inline">
												<label class="m-radio">
												<input type="radio" name="company_certificate" value="Incorporation" required> Incorporation
												<span></span>
												</label>
												<label class="m-radio">
												<input type="radio" name="company_certificate" value="GST" required> GST
												<span></span>
												</label>
												<label class="m-radio">
												<input type="radio" name="company_certificate"  value="MSME" required> MSME
												<span></span>
												</label>
											</div>
										</div>
										<div class="col-lg-6">
											<label>Office:</label>
											<div class="m-radio-inline">
												<label class="m-radio">
												<input type="radio" name="rent_own" value="Rent" required> Rent
												<span></span>
												</label>
												<label class="m-radio">
												<input type="radio" name="rent_own" value="Own" required> Own
												<span></span>
												</label>
											</div>					
										</div>
									</div>
								<div class="form-group m-form__group row">
										<div class="col-lg-6">
											<label>Incorporation date:</label>
											<input class="form-control date-picker" data-date-format="dd/mm/yyyy" name="PF_incorporation_date" id="m_datepicker_1_modal"  required>
										</div>
										<div class="col-lg-6">
											<label class="">Office Address:</label>
											<textarea class="form-control" name="Office_address" required> </textarea>
										</div>
									</div>
								<hr/>
								<div class=" text-right"><!-- PF_Reg__tab1_submit -->
									<button type="submit" class="btn btn-brand">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
				        	</form>
						</div>
						<div class="tab-pane" id="m_tabs_1_2" role="tabpanel">
							<form class="PF_Reg_tab2_form">
							   <div class="text-right">
									<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add1_director_btn"><i class="fa fa-plus"></i></a>
									<!-- <a href="#" class="btn btn-danger m-btn m-btn--icon btn-sm m-btn--icon-only remove_director_btn"><i class="fa fa-trash-o"></i></a> -->
							 	</div> 
							 	<div id="exampleGridd" class="dataTable"></div>
								<hr/>
								<div class="m-form__actions text-right">
									<button type="submit" class="btn btn-brand">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
				        	</form>
						</div>
						<div class="tab-pane" id="m_tabs_1_3" role="tabpanel">
							<form>
								<!--UNA no.confirmation-->
								<div class="form-group m-form__group row">
										<div class="col-lg-12">
											<p style="float: left;">Having UAN number?</p>
											<span class="m-switch m-switch--icon" style="margin-left: 30px;margin-top:-10px;">
												<label>
						                        <input type="checkbox" class="UNA_checkbox" name="is_una_no">
						                        <span></span>
						                        </label>
								            </span>
								            <input class="form-control ESI_reg_UNA_input" type="text" placeholder="Enter UAN no">
										</div>
									</div>

								<div class="PF_reg_director_table" style="padding-bottom: 3%;display:none;">
									<!-- <div id="PF_reg_employers_handsontable"></div> -->
									<div class="text-right">
										<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add_director_btn"><i class="fa fa-plus"></i></a>
										<!-- <a href="#" class="btn btn-danger m-btn m-btn--icon btn-sm m-btn--icon-only remove_director_btn"><i class="fa fa-trash-o"></i></a> -->
								 	</div>
									<div id="exampleGrid" class="dataTable"></div>
				            	</div>
							    <div class=" text-right">
									<button id="data_save" class="btn btn-brand but">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
							</form>

						</div>
					</div>
		        
        		</div>


          <?php }
          if($_REQUEST['eid']=='3'){ ?>
          		<!--ESI return filing-->
          		<div class="form-modal ESI_return_filing_modal">
				 	<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item ">
							<a class="nav-link active" data-toggle="tab" href="#ESI_return_filing_tab1">
								Salary Paid
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#ESI_return_filing_tab2" >
								New Employee
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#ESI_return_filing_tab3">
								Left Employee
							</a>
						</li>
					</ul>
							
					<div class="tab-content">
						<div class="tab-pane active" id="ESI_return_filing_tab1" role="tabpanel">
							<form class="ESI_return_filing_tab1_form">
							   <div class="text-right">
									<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add_salary_paid_btn"><i class="fa fa-plus"></i></a>
									<div id="salary_paid_hsn" class="dataTable"></div>
							 	</div> 

								<hr/>
								<div class=" text-right">
									<button type="button" class="btn btn-brand salary_paid_hsn_submit">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
				        	</form>
						</div>
						<div class="tab-pane " id="ESI_return_filing_tab2" role="tabpanel">
							<form class="ESI_return_filing_tab2_form">
							   <div class="text-right">
									<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add_new_employee_btn"><i class="fa fa-plus"></i></a>
							 	</div> 
							 	<div id="new_employee_hsn" class="dataTable"></div>
								<hr/>
								<div class=" text-right">
									<button class="btn btn-brand new_employee_hsn_submit">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
				        	</form>
						</div>
						<div class="tab-pane " id="ESI_return_filing_tab3" role="tabpanel">
							<form class="ESI_return_filing_tab3_form">
							   <div class="text-right">
									<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add_left_employee_btn"><i class="fa fa-plus"></i></a>
							 	</div> 
							 	<div id="left_employee_hsn" class="dataTable"></div>
								<hr/>
								<div class="m-form__actions text-right">
									<button class="btn btn-brand left_hsn_submit">Submit</button>
									<button type="reset" class="btn btn-secondary">Cancel</button>
								</div>
				        	</form>
						</div>
					</div>
				</div>
        <?php  } ?>
      </div>
 
<!--modal end-->

 <?php	if($_REQUEST['eid']=='2') { ?>
<script type="text/javascript" src="asset_ui_milestone/pf_reg_tab2_hsn.js"></script>
<?php } else if($_REQUEST['eid']=='3') { ?>
<script type="text/javascript" src="asset_ui_milestone/esi_ret1.js"></script>
<?php } ?>
<script type="text/javascript" src="asset_ui_milestone/script.js"></script>
<script type="text/javascript" src="asset_ui_milestone/jquery.serializejson.min.js"></script>












<script type="text/javascript">
$(document).on('submit','#PF_Reg_tab1_form',function(e){
alert();	
		e.preventDefault();	
		
								var form={"eid":"1","docs":"replace","taskid":"13822"};
								var formdata=$('#PF_Reg_tab1_form').serializeJSON();								
								$.extend( form, {"formdata":formdata} );
								var data1=JSON.stringify(form).replace(/'/g,"''");
            $.ajax({
                  url: 'https://oov9bkqx1a.execute-api.ap-south-1.amazonaws.com/Common-API/milestones',
                 type: "POST",
                 data: data1,
                success: function(msg) {  
       	   toastr.success('Submited successfully',"");
    //window.location.href ="dashboard.php";
       			
       			}
   				
          }); return false;
      
   }); 
</script>