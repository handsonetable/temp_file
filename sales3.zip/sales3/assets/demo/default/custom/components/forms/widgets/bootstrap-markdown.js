//== Class definition

var BootstrapMarkdown = function () {    
    //== Private functions
    var demos = function () {
        
    }

    return {
        // public functions
        init: function() {
            demos(); 
        }
    };
}();

//== Initialization
jQuery(document).ready(function() {
    BootstrapMarkdown.init();
});