



	var tdsData2 = function() {
    return [];
  };
	getTDS = tdsData2();
  var hotSettings_tds_items2 = {
		data: getTDS,
		rowHeaders: true,
		colHeaders: ["Name", "Gross Salary", "Net Salary","Aadhar card","PAN no", "UAN no"],
		stretchH: 'all',
		//columnHeaderHeight:40,
		columns: [
			{data: 'name',type: 'text'},
			{data: 'gross_salary',type: 'numeric'},
			{data: 'net_salary',type: 'numeric'},
			{data: 'aadhar_card',type: 'text',validator:aadhar_validator},
			{data: 'pan_card',type: 'text',validator:pan_validator},
			{data: 'uan_no',type: "text"},
		],
		stretchH: 'all',
		colWidths:[200,200,200,200,200,200],
		width: "100%",
		height: 230,
		autoWrapRow: true,
		minRows:5,
		minSpareRows: 1,
		viewportRowRenderingOffset:200,
		viewportColumnRenderingOffset:200,
		contextMenu:true
  };
var hot_tds_items2 = new Handsontable($("#new_employee_hsn")[0],hotSettings_tds_items2);
var visualObjectRow2 = function(sheet_tittle, row) {
var obj = {};
var readData;
for (var i = 0; i < sheet_tittle.countCols(); i++) {
	readData = sheet_tittle.getDataAtCell(row, i);
	if(readData ==0){
		cellDatas = "0";
	}else if(readData == null || readData == ''){
		cellDatas = '';
	}else{
		cellDatas = readData;
	}
	obj[sheet_tittle.colToProp(i)] = cellDatas.toString();
}
return obj
}
$(".new_employee_hsn_submit").click(function(e){
	e.preventDefault();
	var htContents = hot_tds_items2.getSourceData();
	var cleanedGridData = [];
	var obj = {};
	$.each( htContents, function( rowKey, object) {
		if (!hot_tds_items2.isEmptyRow(rowKey)){
		cleanedGridData.push(visualObjectRow2(hot_tds_items2, rowKey));
		}
	});
	if(cleanedGridData.length >0){
		var keys = [];
		var tdsColumns = [{'name':'Name','gross_salary':'Gross Salary','net_salary':'Net Salary','aadhar_no':'Aadhar number','pan_no':'PAN number','uan_no':'UAN number'}];
		$.each(cleanedGridData, function(index, element) {
			for(var key in element){
				if(element[key] == ""){
				 keys.push(key);
				}
			}
		});
		if(keys.length >0){
			toastr["warning"]("Please fill the required field", tdsColumns[0][keys[0]]+" is empty");
			$(".new_employee_hsn_submit").css("pointer-events", "all");
		}
		else{
			var tds_items_data = JSON.stringify(cleanedGridData);
			console.log(tds_items_data);
		}
	}
	else{
		toastr["warning"]("Please fill the details", "Empty details");
		$(".new_employee_hsn_submit").css("pointer-events", "all");
	}
});

$("#hot-display-license-info").remove();
