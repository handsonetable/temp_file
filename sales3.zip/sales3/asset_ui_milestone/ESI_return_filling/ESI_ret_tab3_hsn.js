


	var tdsData3 = function() {
    return [];
  };
	getTDS = tdsData3();
  var hotSettings_tds_items3 = {
		data: getTDS,
		rowHeaders: true,
		colHeaders:   ["Name", "Gross Salary", "Net Salary", "UAN no","Insurance no"],
		stretchH: 'all',
		//columnHeaderHeight:40,
		columns: [
			{data: 'name',type: 'text'},
			{data: 'gross_salary',type: 'numeric'},
			{data: 'net_salary',type: 'numeric'},
			{data: 'uan_no',type: 'text'},
			{data: 'insurance_no',type: 'text'},
		],
		stretchH: 'all',
		colWidths:[240,240,240,240,240],
		width: "100%",
		height: 280,
		autoWrapRow: true,
		minRows:5,
		minSpareRows: 1,
		viewportRowRenderingOffset:200,
		viewportColumnRenderingOffset:200,
		contextMenu:true
  };
var hot_tds_items3 = new Handsontable($("#left_employee_hsn")[0],hotSettings_tds_items3);
var visualObjectRow3 = function(sheet_tittle, row) {
var obj = {};
var readData;
for (var i = 0; i < sheet_tittle.countCols(); i++) {
	readData = sheet_tittle.getDataAtCell(row, i);
	if(readData ==0){
		cellDatas = "0";
	}else if(readData == null || readData == ''){
		cellDatas = '';
	}else{
		cellDatas = readData;
	}
	obj[sheet_tittle.colToProp(i)] = cellDatas.toString();
}
return obj
}
$(".left_hsn_submit").click(function(e){
	e.preventDefault();
	var htContents3 = hot_tds_items3.getSourceData();
	var cleanedGridData = [];
	var obj = {};
	$.each( htContents3, function( rowKey, object) {
		if (!hot_tds_items3.isEmptyRow(rowKey)){
		cleanedGridData.push(visualObjectRow3(hot_tds_items3, rowKey));
		}
	});
	if(cleanedGridData.length >0){
		var keys = [];
		var tdsColumns = [{'name':'Name','gross_salary':'Gross Salary','net_salary':'Net Salary','uan_no':'UAN number','insurance_no':'Insurance number'}];
		$.each(cleanedGridData, function(index, element) {
			for(var key in element){
				if(element[key] == ""){
				 keys.push(key);
				}
			}
		});
		if(keys.length >0){
			toastr["warning"]("Please fill the required field", tdsColumns[0][keys[0]]+" is empty");
			$(".left_hsn_submit").css("pointer-events", "all");
		}
		else{
			var tds_items_data = JSON.stringify(cleanedGridData);
			console.log(tds_items_data);
		}
	}
	else{
		toastr["warning"]("Please fill the details", "Empty details");
		$(".left_hsn_submit").css("pointer-events", "all");
	}
});

$("#hot-display-license-info").remove();
