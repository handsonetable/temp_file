
function rowRenderer(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.NumericRenderer.apply(this, arguments);
	 td.style.fontWeight = 'bold';
}
function cellBackground(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.TextRenderer.apply(this, arguments);
	 td.style.background = 'yellow';
	 td.style.color = 'black';
}
function heading(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.TextRenderer.apply(this, arguments);
	 td.style.fontWeight = 'bold';
	 td.style.fontSize = '12pt';
}
 
					






	var tdsData = function() {
    return [];
  };
	getTDS = tdsData();
  var hotSettings_tds_items = {
		data: getTDS,
		rowHeaders: true,
		colHeaders:['Name','Designation','Address','Aadhar no','Mobile no','Mail id'],
		stretchH: 'all',
		//columnHeaderHeight:40,
		columns: [
			{data: 'name',type: 'text'},
			{data: 'designation',type: 'text'},
			{data: 'address',type: 'text'},
			{data: 'aadhar',type: 'text',validator:aadhar_validator},
			{data: 'mobile',type: 'numeric'},
			{data: 'mail',type: 'text',validator:email_validator},
		],
		stretchH: 'all',
		colWidths:[100,100,100,100,100,100],
		width: "100%",
		height: 280,
		autoWrapRow: true,
		minRows:5,
		minSpareRows: 1,
		contextMenu:true
  };
var hot_tds_items = new Handsontable($("#pf_reg_tab2_hsn_example")[0],hotSettings_tds_items);
var visualObjectRow = function(sheet_tittle, row) {
var obj = {};
var readData;
for (var i = 0; i < sheet_tittle.countCols(); i++) {
	readData = sheet_tittle.getDataAtCell(row, i);
	if(readData ==0){
		cellDatas = "0";
	}else if(readData == null || readData == ''){
		cellDatas = '';
	}else{
		cellDatas = readData;
	}
	obj[sheet_tittle.colToProp(i)] = cellDatas.toString();
}
return obj
}
$(".PF_Reg_tab2_form_submit").click(function(e){
	e.preventDefault();
	var htContents = hot_tds_items.getSourceData();
	var cleanedGridData = [];
	var obj = {};
	$.each( htContents, function( rowKey, object) {
		if (!hot_tds_items.isEmptyRow(rowKey)){
		cleanedGridData.push(visualObjectRow(hot_tds_items, rowKey));
		}
	});
	if(cleanedGridData.length >0){
		var keys = [];
		var tdsColumns = [{'name':'Name','designation':'Designation','address':'Address','aadhar':'Aadhar number','mobile':'Mobile number','mail':'Mail Id'}];
		$.each(cleanedGridData, function(index, element) {
			for(var key in element){
				if(element[key] == ""){
				 keys.push(key);
				}
			}
		});
		if(keys.length >0){
			toastr["warning"]("Please fill the required field", tdsColumns[0][keys[0]]+" is empty");
			$("#tds_data_save").css("pointer-events", "all");
		}
		else{
			var tds_items_data = JSON.stringify(cleanedGridData);
			console.log(tds_items_data);
		}
	}
	else{
		toastr["warning"]("Please fill the details", "Empty details");
		$("#tds_data_save").css("pointer-events", "all");
	}
});

$("#hot-display-license-info").remove();
