
function rowRenderer(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.NumericRenderer.apply(this, arguments);
	 td.style.fontWeight = 'bold';
}
function cellBackground(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.TextRenderer.apply(this, arguments);
	 td.style.background = 'yellow';
	 td.style.color = 'black';
}
function heading(instance, td, row, col, prop, value, cellProperties) {
	 Handsontable.renderers.TextRenderer.apply(this, arguments);
	 td.style.fontWeight = 'bold';
	 td.style.fontSize = '12pt';
}
 
					






	var tdsData = function() {
    return [];
  };
	getTDS = tdsData();
  var hotSettings_tds_items = {
		data: getTDS,
		rowHeaders: true,
		colHeaders: ["Name", "Gross Salary", "Net Slary", "UAN no"],
		stretchH: 'all',
		//columnHeaderHeight:40,
		columns: [
			{data: 'name',type: 'text'},
			{data: 'gross_salary',type: 'numeric'},
			{data: 'net_salary',type: 'numeric'},
			{data: 'uan_no',type: "numeric"},
		],
		stretchH: 'all',
		colWidths:[100,100,100,100],
		width: "100%",
		height: 280,
		autoWrapRow: true,
		minRows:5,
		minSpareRows: 1,
		contextMenu:true
  };
var hot_tds_items = new Handsontable($("#salary_paid_hsn")[0],hotSettings_tds_items);
var visualObjectRow = function(sheet_tittle, row) {
var obj = {};
var readData;
for (var i = 0; i < sheet_tittle.countCols(); i++) {
	readData = sheet_tittle.getDataAtCell(row, i);
	if(readData ==0){
		cellDatas = "0";
	}else if(readData == null || readData == ''){
		cellDatas = '';
	}else{
		cellDatas = readData;
	}
	obj[sheet_tittle.colToProp(i)] = cellDatas.toString();
}
return obj
}
$(".salary_paid_hsn_submit").click(function(e){
	e.preventDefault();
	var htContents = hot_tds_items.getSourceData();
	var cleanedGridData = [];
	var obj = {};
	$.each( htContents, function( rowKey, object) {
		if (!hot_tds_items.isEmptyRow(rowKey)){
		cleanedGridData.push(visualObjectRow(hot_tds_items, rowKey));
		}
	});
	if(cleanedGridData.length >0){
		var keys = [];
		var tdsColumns = [{'name':'Name','gross_salary':'Gross Salary','net_salary':'Net Salary','uan_no':'UAN number'}];
		$.each(cleanedGridData, function(index, element) {
			for(var key in element){
				if(element[key] == ""){
				 keys.push(key);
				}
			}
		});
		if(keys.length >0){
			toastr["warning"]("Please fill the required field", tdsColumns[0][keys[0]]+" is empty");
			$(".salary_paid_hsn_submit").css("pointer-events", "all");
		}
		else{
			var tds_items_data = JSON.stringify(cleanedGridData);
			console.log(tds_items_data);
		}
	}
	else{
		toastr["warning"]("Please fill the details", "Empty details");
		$(".salary_paid_hsn_submit").css("pointer-events", "all");
	}
});

$("#hot-display-license-info").remove();
