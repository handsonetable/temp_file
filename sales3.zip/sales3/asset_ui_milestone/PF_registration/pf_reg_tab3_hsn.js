

	var tdsData3 = function() {
    return [];
  };
	getTDS3 = tdsData3();
  var hotSettings_tds_items3 = {
		data: getTDS3,
		rowHeaders: true,
		colHeaders:['Name','Father Name','DOB','DOJ','Gross Salary','Address1','Address2','Pin','City','State','Bank account'],
		stretchH: 'all',
		//columnHeaderHeight:40,
		columns: [
			{data: 'name',type: 'text'},
			{data: 'father_name',type: 'text'},
			{data: 'dob',type: 'date',dateFormat: 'YYYY/MM/DD',correctFormat: true},
			{data: 'doj',type: 'date',dateFormat: 'YYYY/MM/DD',correctFormat: true},
			{data: 'gross_salary',type: 'numeric'},
			{data: 'address1',type: 'text'},
			{data: 'address2',type: 'text'},
			{data: 'pin',type: 'numeric'},
			{data: 'city',type: 'text'},
			{data: 'state',type: 'text'},
			{data: 'bank_account',type: 'text'},
		],
		stretchH: 'all',
		colWidths:[200,200,200,200,200,200,200,200,200,200,200],
		width: "100%",
		height: 280,
		autoWrapRow: true,
		minRows:3,
		minSpareRows: 1,
		viewportRowRenderingOffset:200,
		viewportColumnRenderingOffset:200,
		contextMenu:true
  };
var hot_tds_items3 = new Handsontable($("#pf_reg_tab3_hsn_example")[0],hotSettings_tds_items3);
var visualObjectRow3 = function(sheet_tittle, row) {
var obj = {};
var readData;
for (var i = 0; i < sheet_tittle.countCols(); i++) {
	readData = sheet_tittle.getDataAtCell(row, i);
	if(readData ==0){
		cellDatas = "0";
	}else if(readData == null || readData == ''){
		cellDatas = '';
	}else{
		cellDatas = readData;
	}
	obj[sheet_tittle.colToProp(i)] = cellDatas.toString();
}
return obj
}
/*$(".PF_Reg_tab3_form_submit").click(function(e){
	e.preventDefault();
	var htContents3 = hot_tds_items3.getSourceData();
	var cleanedGridData3 = [];
	var obj = {};
	$.each( htContents3, function( rowKey, object) {
		if (!hot_tds_items3.isEmptyRow(rowKey)){
		cleanedGridData3.push(visualObjectRow3(hot_tds_items3, rowKey));
		}
	});
	if(cleanedGridData3.length >0){
		var keys = [];
		var tdsColumns = [{'name':'Name','father_name':'Father name','dob':'Dob','doj':'Doj','gross_salary':'Gross Salary','address1':'Adress1','address2':'Address2','pin':'Pin','city':'City','state':'State','bank_account':'Bank Account'}];
		$.each(cleanedGridData3, function(index, element) {
			for(var key in element){
				if(element[key] == ""){
				 keys.push(key);
				}
			}
		});
		if(keys.length >0){
			toastr["warning"]("Please fill the required field", tdsColumns[0][keys[0]]+" is empty");
			$("#tds_data_save").css("pointer-events", "all");
		}
		else{
			var tds_items_data = JSON.stringify(cleanedGridData3);
			console.log(tds_items_data);
		}
	}
	else{
		toastr["warning"]("Please fill the details", "Empty details");
		$("#tds_data_save").css("pointer-events", "all");
	}
});*/

$("#hot-display-license-info").remove();

