/*salary_paid_hsn*/


		 var ESI_rf_salary_data =  [  {}   ];

			var salary_paid_hsn_element = document.querySelector('#salary_paid_hsn');
			var salary_paid_hsn_data = {
			  data: ESI_rf_salary_data,
				colHeaders:  ["Name", "Gross Salary", "Net Slary", "Select"],

			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "text" },
			        { data: "d", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [25,25,25,25],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};

			
			var salary_paid_hsn_init = new Handsontable(salary_paid_hsn_element, salary_paid_hsn_data);

			
/*new emp hsn*/


			var ESI_return_filing_new_emp_data =  [  {a: '', b: '', c: '',d:'e'}   ];

			var new_emp_hsn_element = document.querySelector('#salary_paid_hsn');
			var new_emp_hsn_data = {
			  data: ESI_return_filing_new_emp_data,
				colHeaders:  ["Name", "Gross Salary", "Net Slary", "Select "],

			   columns: [
			        { data: "a", type: "text" },
			        { data: "b", type: "text" },
			        { data: "c", type: "text" },
			        { data: "d", type: "text" }
			    ],

				stretchH: 'all',
				width: "90%",
				colWidths: [25,25,25,25],
				height:200,
				autoWrapRow: true,
				manualRowResize: true,
				manualColumnResize: true,
				rowHeaders: true,
				manualRowMove: false,
				manualColumnMove: false,
				contextMenu: true,
				filters: false,
				dropdownMenu: false,
				columnSorting: false,
				sortIndicator: true
			};

			
			var new_emp_hsn_init = new Handsontable(new_emp_hsn_element, new_emp_hsn_data);


			$(document).on("click",".add_salary_paid_btn", function() {
			    ESI_rf_salary_data.push({a: '', b: '', c: '',d: 'a'});
			    salary_paid_hsn_init.render();
			    return false;
			});