<?php
//error_reporting(E_ALL);
//ini_set("display_errors", 1);
/*session_start();
if(isset($_REQUEST['employee_id']))
{
$_SESSION['id'] = base64_decode($_REQUEST['employee_id']);	
$_SESSION['username'] = base64_decode($_REQUEST['employee_name']);	
}
if(!isset($_SESSION['id'])){
	header("location: https://indiafilings.company");
}

include 'elements/class-list-util.php';
include('elements/admindbconnect.php');	

if($_REQUEST['eng']=='all')
{

         $rmname=array();
         $rm_stmt=mysqli_query($dbcon,"select id,employee_id,name from employee_profile");
         while($rm_row=mysqli_fetch_array($rm_stmt))
          {
	      $rmname[$rm_row['employee_id']]=$rm_row['name'];
          }
	
//$qr = mysqli_query($dbcon,"select e.uid,e.engagement_id,m.mobile,m.name as cname,e.rm,m.email,sm.service,m.business_name from engagements e LEFT JOIN bmaster_dump bd on bd.uid=e.uid LEFT JOIN master m on m.uid=e.uid LEFT JOIN service_master sm on sm.id=e.service_id where e.service_id in ('1','3','4','5','6','7','8','9','10','12','13','17','133','134','135','136','137','79','87','110','23','24','91','92','93','94','107','128') and bd.uid is NULL group by e.uid");
	
$qr = mysqli_query($dbcon,"select e.uid,e.engagement_id,m.mobile,m.name as cname,e.rm,e.ba,m.email,sm.service,m.business_name from engagements e INNER JOIN master m on m.uid=e.uid LEFT JOIN service_master sm on sm.id=e.service_id where e.engagement_status='0' and e.service_id='125' limit 5000");
	
	$data_array = array(); 
	
	while($rows =mysqli_fetch_array($qr)) 
	
	{ 
	
	 $data[] = array(
        'uid' => $rows['uid'],
        'service' => $rows['service'],
        'mobile' => $rows['mobile'],
		'engagement_id' => $rows['engagement_id'],
		'rmname' => $rmname[$rows['rm']],
		'baname' => $rmname[$rows['ba']],
		'email' => $rows['email'],
		'cname' => $rows['cname'],
		'business_name' => $rows['business_name']
    );
	
	}

// for ($i = 0; $i < 10; $i++) {
// 	$data = array_merge($data, $data);
// }

$datatable = ! empty( $_REQUEST[ 'datatable' ] ) ? $_REQUEST[ 'datatable' ] : array();
$datatable = array_merge( array( 'pagination' => array(), 'sort' => array(), 'query' => array() ), $datatable );

// search filter by keywords
$filter = isset( $datatable[ 'query' ][ 'generalSearch' ] ) && is_string( $datatable[ 'query' ][ 'generalSearch' ] ) ? $datatable[ 'query' ][ 'generalSearch' ] : '';
if ( ! empty( $filter ) ) {
	$data = array_filter( $data, function ( $a ) use ( $filter ) {
		return (boolean)preg_grep( "/$filter/i", (array)$a );
	} );
	unset( $datatable[ 'query' ][ 'generalSearch' ] );
}

// filter by field query
$query = isset( $datatable[ 'query' ] ) && is_array( $datatable[ 'query' ] ) ? $datatable[ 'query' ] : null;
if ( is_array( $query ) ) {
	$query = array_filter( $query );
	foreach ( $query as $key => $val ) {
		$data = list_filter( $data, array( $key => $val ) );
	}
}

$sort  = ! empty( $datatable[ 'sort' ][ 'sort' ] ) ? $datatable[ 'sort' ][ 'sort' ] : 'asc';
$field = ! empty( $datatable[ 'sort' ][ 'field' ] ) ? $datatable[ 'sort' ][ 'field' ] : 'RecordID';

$meta    = array();
$page    = ! empty( $datatable[ 'pagination' ][ 'page' ] ) ? (int)$datatable[ 'pagination' ][ 'page' ] : 1;
$perpage = ! empty( $datatable[ 'pagination' ][ 'perpage' ] ) ? (int)$datatable[ 'pagination' ][ 'perpage' ] : -1;

$pages = 1;
$total = count( $data ); // total items in array

// sort
usort( $data, function ( $a, $b ) use ( $sort, $field ) {
	if ( ! isset( $a->$field ) || ! isset( $b->$field ) ) {
		return false;
	}

	if ( $sort === 'asc' ) {
		return $a->$field > $b->$field ? true : false;
	}

	return $a->$field < $b->$field ? true : false;
} );

// $perpage 0; get all data
if ( $perpage > 0 ) {
	$pages  = ceil( $total / $perpage ); // calculate total pages
	$page   = max( $page, 1 ); // get 1 page when $_REQUEST['page'] <= 0
	$page   = min( $page, $pages ); // get last page when $_REQUEST['page'] > $totalPages
	$offset = ( $page - 1 ) * $perpage;
	if ( $offset < 0 ) {
		$offset = 0;
	}

	$data = array_slice( $data, $offset, $perpage, true );
}

$meta = array(
	'page'    => $page,
	'pages'   => $pages,
	'perpage' => $perpage,
	'total'   => $total,
);

header( 'Content-Type: application/json' );
header( 'Access-Control-Allow-Origin: *' );
header( 'Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS' );
header( 'Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description' );

$result = array(
	'meta' => $meta + array(
			'sort'  => $sort,
			'field' => $field,
		),
	'data' => $data,
);

echo json_encode( $result, JSON_PRETTY_PRINT );
die();
}
*/
		
/* if(isset($_POST['bname'])){
	
	$expiry = date('Y-m-d', strtotime('+1 years'));
	$select=mysqli_query($con,"select * from bmaster where uid='".$_POST['uid']."'");
	$count=$select->num_rows;
	echo"hai";
	if($count==0)
	{	
	$r=mysqli_query($con, "INSERT INTO bmaster (uid,business_name,home_url,status,created_on,access) values('".$_POST['uid']."','".$_POST['bname']."','v1/','1','".date('Y-m-d H:i:s')."','1')");
	}
  $r1=mysqli_query($dbcon, "INSERT INTO bmaster_dump (uid,business_name,home_url,status,created_on,access) values('".$_POST['uid']."','".$_POST['bname']."','v1/','1','".date('Y-m-d H:i:s')."','1')");
    die("1");
}	 */
?>


<!DOCTYPE html>
<html lang="en" >
	<!-- begin::Head -->
	<head>
		<meta charset="utf-8" />
		<title>
			IndiaFilings | iCFO
		</title>
		<meta name="description" content="Initialized via remote ajax json data">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!--begin::Web font -->
		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
		<script>
          WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
		</script>
		<!--end::Web font -->
        <!--begin::Base Styles -->
		<link href="assets/vendors/base/vendors.bundle.css" rel="stylesheet" type="text/css" />
		<link href="assets/demo/default/base/style.bundle.css" rel="stylesheet" type="text/css" />
		<link href="assets/handsontable/dist/handsontable.full.min.css" rel="stylesheet" media="screen">
		<script src="assets/handsontable/dist/handsontable.full.min.js"></script>
		<!--end::Base Styles -->

		<!--handsontable-->
		
		


		<script src="assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
		<script src="assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
		<script src="assets/jquery.base64.js" type="text/javascript"></script>

<script type="text/javascript" src="asset_ui_milestone/script.js"></script>
		<link rel="shortcut icon" href="favicon.ico" />
		<style>
		.vl { border-left: 1px solid #ebedf2; }
		.table-bordered tr th {border: 1px solid #c9c4e2 !important;}
		.table-bordered tr td {border: 1px solid #c9c4e2 !important;}
		.row{margin-right: 0px !important;margin-left: 0px !important;}
		.m-form__group{padding: 10px 5px 2px 5px !important;}
		</style>

	</head>
	<!-- end::Head -->
    <!-- end::Body -->
	
	
	<body class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default m-brand--minimize m-aside-left--minimize">
		<!-- begin:: Page -->
		<div class="m-grid m-grid--hor m-grid--root m-page">
			<?php include "header.php"; ?>		
			<!-- begin::Body -->
	<div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
	<?php include "left-menu.php"; ?>	 
	<div class="m-grid__item m-grid__item--fluid m-wrapper">
	
    <div class="modal fade" id="dynamic_form" tabindex="-1" role="dialog" aria-labelledby="memberModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            
            <div class="dash">
             <!-- Content goes in here -->
            </div>
        </div>
    </div>
    </div>
	
	
	<?php // include "forms/promoter-form.php"; ?>	
	
	<div class="m-content">
		<div class="m-portlet">
			<div class="row">
				<div class="col-lg-8">
					<div class="m-portlet__body">
						<ul class="nav nav-tabs  m-tabs-line m-tabs-line--primary" role="tablist">
							<li class="nav-item m-tabs__item">
							<a class="nav-link m-tabs__link active" data-toggle="tab" href="#m_tabs_8_1" role="tab">
							<i class="la la-home"></i>Dashboard</a>
							</li>
							<li class="nav-item m-tabs__item">
							<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_tabs_8_3" role="tab">
								<i class="la la-comments-o"></i>Customer Chat</a>
							</li>
							<li class="nav-item m-tabs__item">
							<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_tabs_8_2" role="tab">
							<i class="la la-sticky-note-o"></i>Internal Notes</a>
							</li>
							<li class="nav-item m-tabs__item">
							    <a class="nav-link m-tabs__link " data-toggle="tab" href="#m_tabs_8_4" role="tab">
								<i class="la la-file-pdf-o"></i>Templates</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link " data-toggle="tab" href="#m_tabs_8_5" role="tab">
								<i class="la la-envelope-o"></i>Emails</a>
							</li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane active" id="m_tabs_8_1" role="tabpanel">
								<div class="row">
									<div class="col-md-5">
						            <h4 style="text-align: -webkit-auto;font-weight: bold;font-size: 24px;">Bharani - 09739447744</h4><br>
									</div>
								</div>
																			
								<table class="table table-bordered table-striped">
                                                <thead>
                                                    <tr>
                                                        <th> RM Name </th>
                                                        <th> BA Name </th>
														<th> Engagement Type </th>
														<th> Total Days </th>
                                                        <th> Last Email </th>
														<th> Next Followup </th>
                                                       
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>SURENDAR P</td>
                                                        <td>Indiafilings</td>
														  <td>Private Limited Company</td>
                                                        <td>79</td>
                                                        <td>12 Days ago</td>
														<td> </td>
                                                       
                                                    </tr>
                                                </tbody>
                                </table>
                                <div id="exam"></div>
								<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
								<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
								<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>								
																			
							</div>
						    <div class="tab-pane" id="m_tabs_8_2" role="tabpanel">
								It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
							</div>
							<div class="tab-pane" id="m_tabs_8_3" role="tabpanel">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged
							</div>
							<div class="tab-pane" id="m_tabs_8_4" role="tabpanel">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type spe
							</div>
						</div>
					</div>
																
				</div>
				
		<?php 
    /*require 'HTTP/phpdocumentdb.php';
    include "elements/cosmos-connect.php";

    // store JSON document ("id" needed)
  //  $data = '{"id":"1234567890", "FirstName": "Paul","LastName": "Smith"}';
   // $result = $col->createDocument($data);
    
    // run query
    $json = $col->query("SELECT * FROM milestones where milestones.eid = 1");
    
    // Debug
    $object = json_decode($json,TRUE);*/
	//print_r($object);
    //var_dump($object->Documents);

		
		
		
		//$search ='{"sort": [{"order.keyword": {"order": "desc"}}],"query":{"match":{"eid":"1"}}}';
		

		//$curl = curl_init();

		//curl_setopt_array($curl, array(
		//  CURLOPT_URL => "https://search-engagements-kaazlrtiev5yaxrftgqdza7wmq.ap-south-1.es.amazonaws.com/engagements/_search",
		//  CURLOPT_RETURNTRANSFER => true,
		//  CURLOPT_ENCODING => "",
		//  CURLOPT_MAXREDIRS => 10,
		//  CURLOPT_TIMEOUT => 30,
		//  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		 // CURLOPT_CUSTOMREQUEST => "POST",
		 // CURLOPT_POSTFIELDS => $search,
		 // CURLOPT_HTTPHEADER => array(
		//	"cache-control: no-cache",
		//	"content-type: application/json"
		 // ),
		//));

		// $response = curl_exec($curl);
		//$err = curl_error($curl);

		//curl_close($curl);

//$data = json_decode($response, TRUE);
//$data['hits']['hits'][0]['_source'];
?>
	
				<div class="vl"></div>
				<div class="col-lg-3">
					<div class="m-portlet__body">
						<ul class="nav nav-tabs  m-tabs-line m-tabs-line--success" role="tablist">
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link active" data-toggle="tab" href="#m_tabs_7_1" role="tab">
									<i class="la la-lightbulb-o"></i>Milestones</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_tabs_7_3" role="tab">
								<i class="la la-file-text-o"></i>Docs</a>
							</li>
						</ul>
						<div class="tab-content">
						<div class="tab-pane active" id="m_tabs_7_1" role="tabpanel">
						<div class="m-list-timeline">
							<div class="m-list-timeline__items">
								<div class="m-list-timeline__item">
									<span class="m-list-timeline__badge m-list-timeline__badge--warning"></span>
									<span class="m-list-timeline__text modaldata" data-id="" data-eid="2" data-toggle="modal" data-target="#dynamic_form">PF Registration</span>
									<span class="m-list-timeline__time">20 mins</span>
								</div>
								<div class="m-list-timeline__item">
									<span class="m-list-timeline__badge m-list-timeline__badge--accent"></span>
										<span class="m-list-timeline__text modaldata" data-id="" data-eid="3" data-toggle="modal" data-target="#dynamic_form">
											ESI Return filing
										</span>
								</div>
								<div class="m-list-timeline__item">
									<span class="m-list-timeline__badge m-list-timeline__badge--success"></span>
										<span class="m-list-timeline__text modaldata" data-id="" data-eid="4" data-toggle="modal" data-target="#dynamic_form" style="white-space: nowrap;">
											Documents-PF/ESI registration
										</span>
								</div>
							
								
							</div>
					    </div>
					    </div>
						<div class="tab-pane" id="m_tabs_7_2" role="tabpanel">
							It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently.
						</div>
						<div class="tab-pane" id="m_tabs_7_3" role="tabpanel">
							Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

						</div>
					    </div>
						</div>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
			 <div id="salary_paid_hsn"></div>								<!-- end:: Body -->
<?php include "footer.php"; ?>	
   
		</div>
		<!-- end:: Page -->
    		       	    
	    <!-- begin::Scroll Top -->
		<div class="m-scroll-top m-scroll-top--skin-top" data-toggle="m-scroll-top" data-scroll-offset="500" data-scroll-speed="300">
			<i class="la la-arrow-up"></i>
		</div>
		<!-- end::Scroll Top -->		   
    	<!--begin::Base Scripts -->
		
		<!--end::Base Scripts -->   
        <!--begin::Page Resources -->
		<!--end::Page Resources -->

<link rel="stylesheet" type="text/css" href="asset_ui_milestone/style.css">
		<script>
		$(document).ready(function(){
		$('#dynamic_form').on('show.bs.modal', function(e) {
               var id = $(e.relatedTarget).data('id'); 
			   var eid = $(e.relatedTarget).data('eid'); 
			  /*var eid=3;*/
           $(e.currentTarget).find('input[name="rid"]').val(id);
		    $(e.currentTarget).find('input[name="eid"]').val(eid);
          var modal = $(this);
          var dataString = 'rid=' + id +'&eid='+eid;
            $.ajax({
                type: "POST",
                url: "index.php",
                data: dataString,
                cache: false,
                success: function (data) {
                    modal.find('.dash').html(data);
                },
                error: function(err) {
                    console.log(err);
                }
			   });
		});
		
		
});
	
</script>		
		

	</body>
	<!-- end::Body -->
</html>
