<?php
	$engagement=$_POST['engagement'];
	if($engagement=="ESI Registration"){ 
		echo '<form class="ESI_reg_form">
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">Business name:</label>
            <input type="text" name="fname" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" name="fmsg" id="message-text"></textarea>
          </div>
        </form>';
	
	}else if($engagement=="PF Registration"){ 
		echo ' <div class="form-modal PF_reg_form">
        	<ul class="nav nav-tabs" role="tablist">
				<li class="nav-item ">
					<a class="nav-link active" data-toggle="tab" href="#m_tabs_1_1">
						PF Registration
					</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link click_trigger" data-toggle="tab" href="#m_tabs_1_2" >
						Authorized Person / Directors
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#m_tabs_1_3">
						All Employers KYC details
					</a>
				</li>
			</ul>
            <div class="tab-content">
				<div class="tab-pane active" id="m_tabs_1_1" role="tabpanel">
					<form class="PF_Reg_tab1_form">
						<div class="form-group m-form__group row">
								<div class="col-lg-6">
									<label>Business Name:</label>
									<input class="form-control m-input" name="business_name" type="text" id="PF_reg_business_name" onblur="business_name(this);" required>
								</div>
								<div class="col-lg-6">
									<label class="">Business Type:</label>
									<select class="form-control m-input" name="business_type" id="PF_reg_business_type"  onblur="business_type(this);" required>
										<option value="" selected>Select business type</option>
										<option value="BPLC">B PLC</option>
										<option vlaue="LLP">LLP</option>
										<option value="Proprietor">Proprietor</option>
									</select>
								</div>
							</div>
						<div class="form-group m-form__group row">
								<div class="col-lg-6">
									<label>Nature of Business:</label>
									<input class="form-control m-input" type="text" name="nature_of_business" onblur="nature_of_business(this);" id="PF_reg_nature_of_business" required>
								</div>
								<div class="col-lg-6">
									<label class="">Company PAN no:</label>
									<input class="form-control m-input" onblur="pan_number(this);" name="company_pan_no" type="text" id="PF_reg_company_pan_no" required>
								</div>
							</div>
						<div class="form-group m-form__group row">
								<div class="col-lg-6">
									<label>Company certificate:</label>
									<div class="m-radio-inline">
										<label class="m-radio">
										<input type="radio" name="company_certificate" value="Incorporation"> Incorporation
										<span></span>
										</label>
										<label class="m-radio">
										<input type="radio" name="company_certificate" value="GST"> GST
										<span></span>
										</label>
										<label class="m-radio">
										<input type="radio" name="company_certificate"  value="MSME"> MSME
										<span></span>
										</label>
									</div>
								</div>
								<div class="col-lg-6">
									<label>Office:</label>
									<div class="m-radio-inline">
										<label class="m-radio">
										<input type="radio" name="rent_own" value="Rent"> Rent
										<span></span>
										</label>
										<label class="m-radio">
										<input type="radio" name="rent_own" value="Own"> Own
										<span></span>
										</label>
									</div>					
								</div>
							</div>
						<div class="form-group m-form__group row">
								<div class="col-lg-6">
									<label>Incorporation date:</label>
									<input class="form-control date-picker" data-date-format="dd/mm/yyyy" name="PF_incorporation_date" id="m_datepicker_1_modal" onblur="incorporation_date(this);" required>
								</div>
								<div class="col-lg-6">
									<label class="">Office Address:</label>
									<textarea class="form-control" name="Office_address"> </textarea>
								</div>
							</div>
						<hr/>
						<div class=" text-right">
							<button type=""  class="btn btn-brand PF_Reg__tab1_submit">Submit</button>
							<button type="reset" class="btn btn-secondary">Cancel</button>
						</div>
		        	</form>
				</div>
				<div class="tab-pane" id="m_tabs_1_2" role="tabpanel">
					<form class="PF_Reg_tab2_form">
					   <div class="text-right">
							<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add1_director_btn"><i class="fa fa-plus"></i></a>
							<!-- <a href="#" class="btn btn-danger m-btn m-btn--icon btn-sm m-btn--icon-only remove_director_btn"><i class="fa fa-trash-o"></i></a> -->
					 	</div> 
					 	
						<hr/>
						<div class="m-form__actions text-right">
							<button type="reset" class="btn btn-brand">Submit</button>
							<button type="reset" class="btn btn-secondary">Cancel</button>
						</div>
		        	</form>
				</div>
				<div class="tab-pane" id="m_tabs_1_3" role="tabpanel">
					<form>
						<!--UNA no.confirmation-->
						<div class="form-group m-form__group row">
								<div class="col-lg-12">
									<p style="float: left;">Having UNA number?</p>
									<span class="m-switch m-switch--icon" style="margin-left: 30px;margin-top:-10px;">
										<label>
				                        <input type="checkbox" class="UNA_checkbox" name="is_una_no">
				                        <span></span>
				                        </label>
						            </span>
						            <input class="form-control ESI_reg_UNA_input" type="text" placeholder="Enter UNA no">
								</div>
							</div>

						<div class="PF_reg_director_table" style="padding-bottom: 3%;display:none;">
							<!-- <div id="PF_reg_employers_handsontable"></div> -->
							<div class="text-right">
								<a class="btn btn-accent m-btn m-btn--icon btn-sm m-btn--icon-only add_director_btn"><i class="fa fa-plus"></i></a>
								<!-- <a href="#" class="btn btn-danger m-btn m-btn--icon btn-sm m-btn--icon-only remove_director_btn"><i class="fa fa-trash-o"></i></a> -->
						 	</div>
							<div id="exampleGrid" class="dataTable"></div>
		            	</div>
					    <div class=" text-right">
							<button id="data_save" class="btn btn-brand but">Submit</button>
							<button type="reset" class="btn btn-secondary">Cancel</button>
						</div>
					</form>

				</div>
			</div>
	        
        </div> ';
	
	}else if($engagement=="ESI return filing"){ 
		echo '<form class="ESI_return_form">
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">PF return name:</label>
            <input type="text" class="form-control" name="fname" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" name="fmsg" id="message-text"></textarea>
          </div>
        </form>';
	
	}else if($engagement=="PF return filing"){ 
		echo '<form class="ESI_return_form">
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">PF return name:</label>
            <input type="text" class="form-control" name="fname" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" name="fmsg" id="message-text"></textarea>
          </div>
        </form>';
	
	}else if($engagement=="Recruitment Service"){ 
		echo '<form class="recruit_service_form">
          <div class="form-group">
            <label for="recipient-name" class="form-control-label">Recruitment name:</label>
            <input type="text" class="form-control" name="fname" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" name="fmsg" id="message-text"></textarea>
          </div>
        </form>';
	
	}else{
		echo "OOps! Confirm your type and try again :(";
	}
?>